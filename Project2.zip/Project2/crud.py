from pymongo import MongoClient

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Connection Variables
        USER = 'dbuser'
        PASS = 'devin1'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30228
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """ Insert a document into the database """
        if data is not None:
            result = self.collection.insert_one(data)  # data should be dictionary
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """ Query for documents from the database """
        if query is not None:
            cursor = self.collection.find(query)
            return list(cursor)
        return []
        
    def update(self, searchData, updateData):

        if searchData is not None:
            result = self.database.animals.update_many(searchData, {"$set": updateData })
        else:
            return "{}"
        return result.raw_result

    def delete(self, deleteData):

        if deleteData is not None:
            result = self.database.animals.delete_many(deleteData)
        else:
            return "{}"
        return result.raw_result
